const p = document.querySelector('p');

p.addEventListener('click', function () {
  this.style.backgroundColor = 'pink';
});
